/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { Toaster } from 'react-hot-toast';
import ScrollToTop from './components/ScrollToTop';
import AIAgent from './components/AIAgent';
import Footer from './components/Footer';
import Header from './components/Header';
import BottomNav from './components/BottomNav';
import Home from './pages/Home';
import ListingDetails from './pages/ListingDetails';
import CategoryPage from './pages/CategoryPage';
import MyBookings from './pages/MyBookings';
import ProviderDashboard from './pages/ProviderDashboard';
import Profile from './pages/Profile';
import CommunityPage from './pages/CommunityPage';
import MarketplacePage from './pages/MarketplacePage';
import GuestServiceCenter from './components/GuestServiceCenter';
import { AuthProvider } from './contexts/AuthContext';
import { LanguageProvider } from './contexts/LanguageContext';

export default function App() {
  return (
    <AuthProvider>
      <LanguageProvider>
        <Router>
          <ScrollToTop />
          <div className="min-h-screen font-sans bg-white flex flex-col">
            <Toaster position="top-center" toastOptions={{ duration: 3000, style: { fontFamily: 'Inter, sans-serif' } }} />
            <Header />
            <div className="flex-grow pt-16 pb-16 md:pb-0">
              <Routes>
                <Route path="/" element={<Home />} />
                <Route path="/category/:categoryId" element={<CategoryPage />} />
                <Route path="/listing/:id" element={<ListingDetails />} />
                <Route path="/my-bookings" element={<MyBookings />} />
                <Route path="/provider" element={<ProviderDashboard />} />
                <Route path="/profile" element={<Profile />} />
                <Route path="/community" element={<CommunityPage />} />
                <Route path="/marketplace" element={<MarketplacePage />} />
              </Routes>
            </div>
            <Footer />
            <BottomNav />
            <GuestServiceCenter />
            <AIAgent />
          </div>
        </Router>
      </LanguageProvider>
    </AuthProvider>
  );
}
