import React, { useState, useRef, useEffect } from 'react';
import { Bot, Send, User, Sparkles, X, Loader2 } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { GoogleGenAI } from '@google/genai';
import { getAllServices, Service } from '../infrastructure/firebase/serviceService';

// Initialize Gemini API
const ai = new GoogleGenAI({ apiKey: import.meta.env.VITE_GEMINI_API_KEY || process.env.GEMINI_API_KEY || '' });

export default function AIAgent() {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState([
    { id: 1, type: 'agent', text: 'مرحباً! أنا المساعد الذكي لمنصة ضيف. كيف يمكنني مساعدتك في التخطيط لرحلتك إلى سوريا اليوم؟' }
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [services, setServices] = useState<Service[]>([]);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (isOpen && services.length === 0) {
      const fetchServices = async () => {
        try {
          const data = await getAllServices();
          setServices(data);
        } catch (error) {
          console.error('Error fetching services for AI Agent:', error);
        }
      };
      fetchServices();
    }
  }, [isOpen, services.length]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || isLoading) return;

    const userText = input.trim();
    const userMsg = { id: Date.now(), type: 'user', text: userText };
    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setIsLoading(true);

    try {
      // Prepare context about the platform's offerings
      const context = `
أنت مساعد ذكي لمنصة "ضيف" (Dayf)، وهي منصة سورية شاملة للسياحة، العلاج، الدراسة، والأعمال.
مهمتك هي مساعدة المستخدمين في العثور على أفضل الخدمات والإجابة على استفساراتهم بلباقة واحترافية باللغة العربية.

إليك قائمة بالخدمات المتوفرة حالياً في المنصة:
${services.map(s => `- ${s.title} (${s.type}) في ${s.location}. السعر: $${s.price}/ليلة. التقييم: ${s.rating}. المميزات: ${s.amenities?.join('، ')}`).join('\n')}

استخدم هذه المعلومات لتقديم توصيات دقيقة للمستخدم. إذا سأل المستخدم عن شيء غير متوفر، اقترح عليه أقرب بديل متاح من القائمة أعلاه.
كن مختصراً ومفيداً وودوداً.
`;

      const chatHistory = messages.map(m => `${m.type === 'user' ? 'المستخدم' : 'المساعد'}: ${m.text}`).join('\n');
      const prompt = `${context}\n\nتاريخ المحادثة:\n${chatHistory}\n\nالمستخدم: ${userText}\nالمساعد:`;

      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: prompt,
      });

      const aiText = response.text || 'عذراً، لم أتمكن من معالجة طلبك في الوقت الحالي. يرجى المحاولة مرة أخرى.';
      
      setMessages(prev => [...prev, { id: Date.now() + 1, type: 'agent', text: aiText }]);
    } catch (error) {
      console.error('Error generating AI response:', error);
      setMessages(prev => [...prev, { id: Date.now() + 1, type: 'agent', text: 'عذراً، حدث خطأ أثناء الاتصال بالخادم. يرجى المحاولة لاحقاً.' }]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <>
      {/* Floating Action Button */}
      <button
        onClick={() => setIsOpen(true)}
        className={`fixed bottom-6 left-6 z-40 bg-emerald-600 text-white p-4 rounded-full shadow-2xl hover:bg-emerald-700 hover:scale-110 transition-all duration-300 flex items-center justify-center ${isOpen ? 'scale-0 opacity-0 pointer-events-none' : 'scale-100 opacity-100'}`}
      >
        <Bot className="w-7 h-7" />
        <span className="absolute -top-2 -right-2 bg-red-500 text-white text-xs font-bold px-2 py-1 rounded-full border-2 border-white">
          1
        </span>
      </button>

      {/* Chat Window */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 50, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 50, scale: 0.9 }}
            transition={{ type: 'spring', bounce: 0.4, duration: 0.6 }}
            className="fixed bottom-6 left-6 z-50 w-[350px] sm:w-[400px] h-[500px] bg-white rounded-3xl shadow-2xl flex flex-col overflow-hidden border border-gray-100"
          >
            {/* Header */}
            <div className="bg-emerald-600 p-4 flex justify-between items-center text-white">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center backdrop-blur-sm">
                  <Bot className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="font-bold text-lg">المساعد الذكي</h3>
                  <p className="text-emerald-100 text-xs flex items-center gap-1">
                    <span className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></span>
                    متصل الآن
                  </p>
                </div>
              </div>
              <button 
                onClick={() => setIsOpen(false)}
                className="p-2 hover:bg-white/20 rounded-full transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Messages Area */}
            <div className="flex-1 p-4 overflow-y-auto bg-gray-50 flex flex-col gap-4">
              {messages.map((msg) => (
                <div 
                  key={msg.id} 
                  className={`flex gap-3 max-w-[85%] ${msg.type === 'user' ? 'self-end flex-row-reverse' : 'self-start'}`}
                >
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${msg.type === 'user' ? 'bg-gray-200 text-gray-600' : 'bg-emerald-100 text-emerald-600'}`}>
                    {msg.type === 'user' ? <User className="w-4 h-4" /> : <Bot className="w-4 h-4" />}
                  </div>
                  <div className={`p-3 rounded-2xl text-sm whitespace-pre-wrap leading-relaxed ${
                    msg.type === 'user' 
                      ? 'bg-emerald-600 text-white rounded-tl-none' 
                      : 'bg-white text-gray-800 border border-gray-100 shadow-sm rounded-tr-none'
                  }`}>
                    {msg.text}
                  </div>
                </div>
              ))}
              {isLoading && (
                <div className="flex gap-3 max-w-[85%] self-start">
                  <div className="w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 bg-emerald-100 text-emerald-600">
                    <Bot className="w-4 h-4" />
                  </div>
                  <div className="p-4 rounded-2xl bg-white border border-gray-100 shadow-sm rounded-tr-none flex items-center gap-2">
                    <Loader2 className="w-4 h-4 animate-spin text-emerald-600" />
                    <span className="text-xs text-gray-500">يفكر...</span>
                  </div>
                </div>
              )}
              <div ref={messagesEndRef} />
            </div>

            {/* Input Area */}
            <div className="p-4 bg-white border-t border-gray-100">
              <form onSubmit={handleSend} className="relative flex items-center">
                <input
                  type="text"
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  placeholder="اسألني عن أي شيء..."
                  className="w-full bg-gray-50 border border-gray-200 rounded-full py-3 pr-4 pl-12 focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 transition-all text-sm"
                  dir="rtl"
                  disabled={isLoading}
                />
                <button 
                  type="submit"
                  disabled={!input.trim() || isLoading}
                  className="absolute left-2 p-2 bg-emerald-600 text-white rounded-full hover:bg-emerald-700 disabled:opacity-50 disabled:hover:bg-emerald-600 transition-colors"
                >
                  <Send className="w-4 h-4 rtl:-scale-x-100" />
                </button>
              </form>
              <div className="mt-2 flex items-center justify-center gap-1 text-xs text-gray-400">
                <Sparkles className="w-3 h-3 text-emerald-500" />
                <span>مدعوم بالذكاء الاصطناعي (Gemini)</span>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
