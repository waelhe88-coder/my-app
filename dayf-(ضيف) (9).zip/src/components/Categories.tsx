import React from 'react';
import { Link } from 'react-router-dom';
import { Plane, Stethoscope, GraduationCap, Briefcase, ChevronLeft } from 'lucide-react';
import { motion } from 'motion/react';
import { MAIN_CATEGORIES } from '../data/categories';

import { useLanguage } from '../contexts/LanguageContext';

export default function Categories() {
  const { t } = useLanguage();
  const colorMap = {
    emerald: 'bg-emerald-50 text-emerald-600',
    blue: 'bg-blue-50 text-blue-600',
    amber: 'bg-amber-50 text-amber-600',
    purple: 'bg-purple-50 text-purple-600',
  };

  const badgeColorMap = {
    emerald: 'bg-emerald-100 text-emerald-700 hover:bg-emerald-200',
    blue: 'bg-blue-100 text-blue-700 hover:bg-blue-200',
    amber: 'bg-amber-100 text-amber-700 hover:bg-amber-200',
    purple: 'bg-purple-100 text-purple-700 hover:bg-purple-200',
  };

  return (
    <section className="pt-4 pb-16 bg-white relative overflow-hidden">
      {/* Decorative Background Elements */}
      <div className="absolute top-0 left-0 w-full h-full overflow-hidden pointer-events-none">
        <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] rounded-full bg-emerald-50/50 blur-3xl opacity-50" />
        <div className="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] rounded-full bg-blue-50/50 blur-3xl opacity-50" />
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center mb-20 px-4">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-emerald-50 text-emerald-600 text-sm font-bold mb-6"
          >
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
            خدماتنا الرئيسية
          </motion.div>
          <motion.h2 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
            className="text-4xl md:text-5xl font-black text-gray-900 mb-6 leading-tight tracking-tight"
          >
            {t('categories.title')}
          </motion.h2>
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.2 }}
            className="text-lg md:text-xl text-gray-500 max-w-2xl mx-auto leading-relaxed"
          >
            {t('categories.subtitle')}
          </motion.p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {MAIN_CATEGORIES.map((category, index) => {
            const Icon = category.icon;
            const colorClass = colorMap[category.color as keyof typeof colorMap];
            const badgeClass = badgeColorMap[category.color as keyof typeof badgeColorMap];
            
            return (
              <motion.div
                key={category.id}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                className="group relative bg-white rounded-[2rem] overflow-hidden shadow-[0_8px_30px_rgba(0,0,0,0.04)] hover:shadow-[0_20px_40px_rgba(0,0,0,0.08)] transition-all duration-500 border border-gray-100 flex flex-col hover:-translate-y-2"
              >
                <Link to={`/category/${category.id}`} className="block h-56 overflow-hidden relative shrink-0">
                  <img 
                    src={category.image} 
                    alt={category.name} 
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700 ease-out"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent opacity-80 group-hover:opacity-90 transition-opacity duration-500"></div>
                  
                  <div className={`absolute top-4 right-4 w-12 h-12 rounded-2xl flex items-center justify-center bg-white/20 backdrop-blur-md border border-white/30 text-white shadow-lg transform group-hover:scale-110 transition-transform duration-500`}>
                    <Icon className="w-6 h-6" />
                  </div>
                  
                  <div className="absolute bottom-6 right-6 left-6">
                    <h3 className="text-2xl font-black text-white drop-shadow-md mb-2 transform group-hover:translate-x-2 transition-transform duration-500">
                      {category.name}
                    </h3>
                    <p className="text-white/80 text-sm line-clamp-2 leading-relaxed opacity-0 group-hover:opacity-100 transform translate-y-4 group-hover:translate-y-0 transition-all duration-500">
                      {category.description}
                    </p>
                  </div>
                </Link>
                
                <div className="p-6 flex flex-col flex-1 bg-white relative z-10">
                  {/* Subcategories Tags */}
                  <div className="flex flex-wrap gap-2 mb-6 mt-auto">
                    {category.subCategories.slice(0, 3).map((sub) => (
                      <Link 
                        key={sub.id}
                        to={`/category/${category.id}?sub=${sub.id}`}
                        className={`text-xs font-bold px-3 py-1.5 rounded-xl transition-colors truncate max-w-full ${badgeClass}`}
                      >
                        {sub.name}
                      </Link>
                    ))}
                    {category.subCategories.length > 3 && (
                      <span className="text-xs font-bold px-3 py-1.5 rounded-xl bg-gray-50 text-gray-500 shrink-0 border border-gray-100">
                        +{category.subCategories.length - 3}
                      </span>
                    )}
                  </div>

                  <Link to={`/category/${category.id}`} className="inline-flex items-center justify-between w-full text-gray-900 font-bold hover:text-emerald-600 transition-colors group/link mt-auto pt-4 border-t border-gray-100">
                    <span>استكشف المزيد</span>
                    <div className="w-8 h-8 rounded-full bg-gray-50 flex items-center justify-center group-hover/link:bg-emerald-50 group-hover/link:text-emerald-600 transition-colors">
                      <ChevronLeft className="w-4 h-4 rtl:rotate-180 transform group-hover/link:-translate-x-1 transition-transform" />
                    </div>
                  </Link>
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
