import React from 'react';
import { Facebook, Twitter, Instagram, Linkedin, Mail, Phone, MapPin } from 'lucide-react';
import toast from 'react-hot-toast';
import { Link } from 'react-router-dom';

export default function Footer() {
  const handleComingSoon = (e: React.MouseEvent) => {
    e.preventDefault();
    toast('سيتم تفعيل هذه الصفحة قريباً', { icon: '⏳' });
  };

  return (
    <footer className="bg-gray-900 text-gray-300 py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12">
          {/* Brand */}
          <div>
            <div className="flex items-center gap-2 mb-6">
              <div className="w-10 h-10 bg-emerald-600 rounded-xl flex items-center justify-center text-white font-bold text-xl">
                ض
              </div>
              <span className="font-bold text-2xl text-white tracking-tight">ضيف</span>
            </div>
            <p className="text-gray-400 mb-6 leading-relaxed">
              منصة السياحة السورية الشاملة. نجمع لك أفضل خيارات الإقامة، العلاج، الدراسة، والأعمال في مكان واحد.
            </p>
            <div className="flex items-center gap-4">
              <a href="#" onClick={handleComingSoon} className="w-10 h-10 rounded-full bg-gray-800 flex items-center justify-center hover:bg-emerald-600 hover:text-white transition-colors">
                <Facebook className="w-5 h-5" />
              </a>
              <a href="#" onClick={handleComingSoon} className="w-10 h-10 rounded-full bg-gray-800 flex items-center justify-center hover:bg-emerald-600 hover:text-white transition-colors">
                <Twitter className="w-5 h-5" />
              </a>
              <a href="#" onClick={handleComingSoon} className="w-10 h-10 rounded-full bg-gray-800 flex items-center justify-center hover:bg-emerald-600 hover:text-white transition-colors">
                <Instagram className="w-5 h-5" />
              </a>
              <a href="#" onClick={handleComingSoon} className="w-10 h-10 rounded-full bg-gray-800 flex items-center justify-center hover:bg-emerald-600 hover:text-white transition-colors">
                <Linkedin className="w-5 h-5" />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-white font-bold text-lg mb-6">روابط سريعة</h3>
            <ul className="space-y-4">
              <li><a href="#" onClick={handleComingSoon} className="hover:text-emerald-500 transition-colors">عن ضيف</a></li>
              <li><a href="#" onClick={handleComingSoon} className="hover:text-emerald-500 transition-colors">كيف يعمل الموقع</a></li>
              <li><a href="#" onClick={handleComingSoon} className="hover:text-emerald-500 transition-colors">الأسئلة الشائعة</a></li>
              <li><a href="#" onClick={handleComingSoon} className="hover:text-emerald-500 transition-colors">سياسة الخصوصية</a></li>
              <li><a href="#" onClick={handleComingSoon} className="hover:text-emerald-500 transition-colors">الشروط والأحكام</a></li>
            </ul>
          </div>

          {/* Services */}
          <div>
            <h3 className="text-white font-bold text-lg mb-6">خدماتنا</h3>
            <ul className="space-y-4">
              <li><Link to="/category/tourism" className="hover:text-emerald-500 transition-colors">حجز الفنادق والإقامات</Link></li>
              <li><Link to="/category/medical" className="hover:text-emerald-500 transition-colors">السياحة العلاجية</Link></li>
              <li><Link to="/category/education" className="hover:text-emerald-500 transition-colors">القبولات الجامعية</Link></li>
              <li><Link to="/category/business" className="hover:text-emerald-500 transition-colors">فرص الاستثمار</Link></li>
              <li><a href="#" onClick={handleComingSoon} className="hover:text-emerald-500 transition-colors">تنظيم المؤتمرات</a></li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h3 className="text-white font-bold text-lg mb-6">تواصل معنا</h3>
            <ul className="space-y-4">
              <li className="flex items-start gap-3">
                <MapPin className="w-5 h-5 text-emerald-500 mt-1 flex-shrink-0" />
                <span>دمشق، سوريا<br />شارع الثورة، بناء 12</span>
              </li>
              <li className="flex items-center gap-3">
                <Phone className="w-5 h-5 text-emerald-500 flex-shrink-0" />
                <span dir="ltr">+963 11 123 4567</span>
              </li>
              <li className="flex items-center gap-3">
                <Mail className="w-5 h-5 text-emerald-500 flex-shrink-0" />
                <span>info@dayf.sy</span>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-gray-800 mt-16 pt-8 text-center text-gray-500 text-sm">
          <p>© {new Date().getFullYear()} منصة ضيف (Dayf). جميع الحقوق محفوظة.</p>
        </div>
      </div>
    </footer>
  );
}
