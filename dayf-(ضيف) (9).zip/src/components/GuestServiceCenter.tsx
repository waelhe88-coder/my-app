import React, { useState } from 'react';
import { Headset, X, Phone, MessageCircle, ShieldAlert, Map, Info, ChevronLeft } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { useLanguage } from '../contexts/LanguageContext';

export default function GuestServiceCenter() {
  const [isOpen, setIsOpen] = useState(false);
  const { language } = useLanguage();
  const isRTL = language === 'ar';

  return (
    <>
      {/* Floating Button */}
      <button
        onClick={() => setIsOpen(true)}
        className="fixed bottom-24 left-6 z-40 bg-emerald-600 text-white p-4 rounded-2xl shadow-2xl shadow-emerald-200 hover:bg-emerald-700 hover:scale-110 transition-all group"
        title={isRTL ? 'مركز خدمة الضيف' : 'Guest Service Center'}
      >
        <Headset className="w-6 h-6" />
        <span className="absolute right-full mr-3 bg-gray-900 text-white text-xs py-1 px-2 rounded opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap pointer-events-none">
          {isRTL ? 'مركز خدمة الضيف' : 'Guest Service Center'}
        </span>
      </button>

      {/* Modal Overlay */}
      <AnimatePresence>
        {isOpen && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsOpen(false)}
              className="fixed inset-0 bg-black/40 backdrop-blur-sm z-50"
            />
            <motion.div
              initial={{ opacity: 0, scale: 0.9, x: -20, y: 20 }}
              animate={{ opacity: 1, scale: 1, x: 0, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, x: -20, y: 20 }}
              className="fixed bottom-6 left-6 z-50 w-full max-w-sm bg-white rounded-3xl shadow-2xl overflow-hidden border border-gray-100"
            >
              {/* Header */}
              <div className="bg-emerald-600 p-6 text-white relative">
                <button 
                  onClick={() => setIsOpen(false)}
                  className="absolute top-4 right-4 p-1 hover:bg-white/20 rounded-lg transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
                <div className="flex items-center gap-3 mb-2">
                  <div className="w-10 h-10 bg-white/20 rounded-xl flex items-center justify-center">
                    <Headset className="w-6 h-6" />
                  </div>
                  <div>
                    <h3 className="font-bold text-lg">{isRTL ? 'مركز خدمة الضيف' : 'Guest Service Center'}</h3>
                    <p className="text-emerald-100 text-xs">{isRTL ? 'نحن هنا لمساعدتك على مدار الساعة' : 'We are here to help 24/7'}</p>
                  </div>
                </div>
              </div>

              {/* Content */}
              <div className="p-6 space-y-4 max-h-[70vh] overflow-y-auto">
                {/* Emergency Section */}
                <div className="bg-red-50 border border-red-100 rounded-2xl p-4">
                  <div className="flex items-center gap-2 text-red-700 font-bold text-sm mb-3">
                    <ShieldAlert className="w-4 h-4" />
                    {isRTL ? 'حالات الطوارئ' : 'Emergency'}
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    <button className="flex items-center justify-center gap-2 bg-white border border-red-200 text-red-600 py-2 rounded-xl text-xs font-bold hover:bg-red-50 transition-colors">
                      <Phone className="w-3 h-3" />
                      {isRTL ? 'الإسعاف' : 'Ambulance'}
                    </button>
                    <button className="flex items-center justify-center gap-2 bg-white border border-red-200 text-red-600 py-2 rounded-xl text-xs font-bold hover:bg-red-50 transition-colors">
                      <Phone className="w-3 h-3" />
                      {isRTL ? 'الشرطة' : 'Police'}
                    </button>
                  </div>
                </div>

                {/* Support Options */}
                <div className="space-y-2">
                  <h4 className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">
                    {isRTL ? 'خيارات الدعم' : 'Support Options'}
                  </h4>
                  <button className="w-full flex items-center justify-between p-3 bg-gray-50 rounded-2xl hover:bg-gray-100 transition-colors group">
                    <div className="flex items-center gap-3">
                      <MessageCircle className="w-5 h-5 text-emerald-600" />
                      <span className="text-sm font-medium text-gray-700">{isRTL ? 'محادثة مباشرة مع الدعم' : 'Live Chat Support'}</span>
                    </div>
                    <ChevronLeft className={`w-4 h-4 text-gray-300 ${isRTL ? '' : 'rotate-180'}`} />
                  </button>
                  <button className="w-full flex items-center justify-between p-3 bg-gray-50 rounded-2xl hover:bg-gray-100 transition-colors group">
                    <div className="flex items-center gap-3">
                      <Map className="w-5 h-5 text-blue-600" />
                      <span className="text-sm font-medium text-gray-700">{isRTL ? 'دليل المناطق السياحية' : 'Tourist Area Guide'}</span>
                    </div>
                    <ChevronLeft className={`w-4 h-4 text-gray-300 ${isRTL ? '' : 'rotate-180'}`} />
                  </button>
                  <button className="w-full flex items-center justify-between p-3 bg-gray-50 rounded-2xl hover:bg-gray-100 transition-colors group">
                    <div className="flex items-center gap-3">
                      <Info className="w-5 h-5 text-amber-600" />
                      <span className="text-sm font-medium text-gray-700">{isRTL ? 'الأسئلة الشائعة' : 'FAQs'}</span>
                    </div>
                    <ChevronLeft className={`w-4 h-4 text-gray-300 ${isRTL ? '' : 'rotate-180'}`} />
                  </button>
                </div>

                {/* Active Booking Quick Access */}
                <div className="pt-4 border-t border-gray-100">
                  <h4 className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-3">
                    {isRTL ? 'حجزك النشط' : 'Active Booking'}
                  </h4>
                  <div className="bg-emerald-50 rounded-2xl p-4 border border-emerald-100">
                    <div className="font-bold text-gray-900 text-sm mb-1">فندق الشام - دمشق</div>
                    <div className="text-xs text-emerald-700 mb-3">الحالة: قيد الإقامة</div>
                    <button className="w-full bg-emerald-600 text-white py-2 rounded-xl text-xs font-bold">
                      {isRTL ? 'تواصل مع المزود' : 'Contact Provider'}
                    </button>
                  </div>
                </div>
              </div>

              {/* Footer */}
              <div className="p-4 bg-gray-50 border-t border-gray-100 text-center">
                <p className="text-[10px] text-gray-400">
                  {isRTL ? 'منصة ضيف - رفيقك في كل خطوة' : 'Dayf Platform - Your companion at every step'}
                </p>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </>
  );
}
