import React, { useState, useEffect } from 'react';
import { Search, MapPin, Calendar, Users, Sparkles } from 'lucide-react';
import { motion, useScroll, useTransform } from 'motion/react';
import { Link, useLocation } from 'react-router-dom';

export default function Header() {
  const { scrollY } = useScroll();
  const [isExpanded, setIsExpanded] = useState(true);
  const location = useLocation();
  const isHome = location.pathname === '/';

  useEffect(() => {
    return scrollY.on('change', (latest) => {
      setIsExpanded(latest < 50);
    });
  }, [scrollY]);

  return (
    <motion.header
      className={`fixed top-0 left-0 right-0 z-50 border-b transition-colors duration-300 ${isHome && isExpanded ? 'bg-gradient-to-b from-black/30 to-transparent border-transparent' : 'bg-white border-gray-200 shadow-sm'}`}
      initial={{ height: 'auto' }}
      animate={{ height: isExpanded ? 'auto' : '64px' }}
      transition={{ duration: 0.3, ease: 'easeInOut' }}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
        <Link to="/" className={`text-2xl font-bold ${isHome && isExpanded ? 'text-white' : 'text-emerald-600'}`}>ضيف</Link>
        
        <motion.div
          className={`flex items-center gap-2 bg-white border border-gray-300 rounded-full shadow-sm p-1 cursor-pointer hover:shadow-md transition-all ${isHome && isExpanded ? 'bg-white/90' : 'bg-white'}`}
          animate={{ scale: isExpanded ? 1 : 0.8, opacity: isExpanded ? 1 : 0.8 }}
        >
          <div className="px-4 py-2 text-sm font-medium">أي مكان</div>
          <div className="px-4 py-2 text-sm font-medium border-l border-gray-300">أي أسبوع</div>
          <div className="px-4 py-2 text-sm font-medium text-gray-500 border-l border-gray-300">إضافة ضيوف</div>
          {isExpanded && (
            <div className="bg-emerald-600 text-white p-2 rounded-full">
              <Search className="w-4 h-4" />
            </div>
          )}
        </motion.div>

        <div className="flex items-center gap-4">
          <Link to="/provider" className={`text-sm font-medium ${isHome && isExpanded ? 'text-white' : 'text-gray-700'}`}>استضافة</Link>
          {isExpanded && (
            <div className={`w-8 h-8 rounded-full ${isHome && isExpanded ? 'bg-white/20' : 'bg-gray-200'}`}></div>
          )}
        </div>
      </div>
    </motion.header>
  );
}
