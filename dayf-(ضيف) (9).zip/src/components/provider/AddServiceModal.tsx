import React, { useState, useEffect } from 'react';
import { X, Upload, Loader2, AlertCircle } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import { db } from '../../firebase';
import { collection, addDoc, updateDoc, doc, serverTimestamp } from 'firebase/firestore';
import { Service } from '../../features/services/types';
import { updateService, deleteService } from '../../infrastructure/firebase/serviceService';
import { MAIN_CATEGORIES } from '../../data/categories';

interface AddServiceModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
  service?: Service | null;
}

export default function AddServiceModal({ isOpen, onClose, onSuccess, service }: AddServiceModalProps) {
  const { user } = useAuth();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const [formData, setFormData] = useState({
    title: '',
    mainCategoryId: 'tourism',
    subCategoryId: 'recreational',
    subSubCategoryId: 'all',
    type: 'Hotel',
    location: '',
    price: 0,
    originalPrice: 0,
    images: [''],
    amenities: '',
    features: '',
    description: ''
  });

  useEffect(() => {
    if (service) {
      setFormData({
        title: service.title,
        mainCategoryId: service.mainCategoryId,
        subCategoryId: service.subCategoryId,
        subSubCategoryId: service.subSubCategoryId || 'all',
        type: service.type,
        location: service.location,
        price: service.price,
        originalPrice: service.originalPrice || 0,
        images: service.images,
        amenities: service.amenities?.join(', ') || '',
        features: service.features?.join(', ') || '',
        description: '' // Assuming description might be added later
      });
    } else {
      setFormData({
        title: '',
        mainCategoryId: 'tourism',
        subCategoryId: 'recreational',
        subSubCategoryId: 'all',
        type: 'Hotel',
        location: '',
        price: 0,
        originalPrice: 0,
        images: ['https://images.unsplash.com/photo-1566073771259-6a8506099945?auto=format&fit=crop&q=80&w=1000'],
        amenities: 'واي فاي، تكييف، إفطار مجاني',
        features: 'إلغاء مجاني، دفع عند الوصول',
        description: ''
      });
    }
  }, [service]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;

    setLoading(true);
    setError(null);

    try {
      const serviceData = {
        ...formData,
        price: Number(formData.price),
        originalPrice: Number(formData.originalPrice),
        amenities: formData.amenities.split('،').map(s => s.trim()).filter(s => s),
        features: formData.features.split('،').map(s => s.trim()).filter(s => s),
        authorUid: user.uid,
        rating: service?.rating || 4.5,
        reviews: service?.reviews || 0,
        updatedAt: serverTimestamp()
      };

      if (service?.id) {
        await updateDoc(doc(db, 'services', service.id), serviceData);
      } else {
        await addDoc(collection(db, 'services'), {
          ...serviceData,
          createdAt: serverTimestamp()
        });
      }

      onSuccess();
      onClose();
    } catch (err) {
      console.error('Error saving service:', err);
      setError('فشل في حفظ الخدمة. يرجى المحاولة مرة أخرى.');
    } finally {
      setLoading(false);
    }
  };

  const selectedMainCategory = MAIN_CATEGORIES.find(c => c.id === formData.mainCategoryId);
  const selectedSubCategory = selectedMainCategory?.subCategories.find(s => s.id === formData.subCategoryId);

  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm">
      <div className="bg-white w-full max-w-2xl max-h-[90vh] overflow-y-auto rounded-3xl shadow-2xl">
        <div className="sticky top-0 bg-white p-6 border-b border-gray-100 flex justify-between items-center z-10">
          <h3 className="text-xl font-bold text-gray-900">{service ? 'تعديل الخدمة' : 'إضافة خدمة جديدة'}</h3>
          <button onClick={onClose} className="p-2 hover:bg-gray-100 rounded-full transition-colors">
            <X className="w-6 h-6" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-8 space-y-6">
          {error && (
            <div className="bg-red-50 text-red-700 p-4 rounded-xl flex items-center gap-3 border border-red-100">
              <AlertCircle className="w-5 h-5" />
              <p>{error}</p>
            </div>
          )}

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <label className="text-sm font-bold text-gray-700">عنوان الخدمة</label>
              <input
                required
                type="text"
                value={formData.title}
                onChange={e => setFormData({ ...formData, title: e.target.value })}
                className="w-full bg-gray-50 border border-gray-200 rounded-xl py-3 px-4 focus:outline-none focus:border-emerald-500 transition-all"
                placeholder="مثلاً: فندق الياسمين الدمشقي"
              />
            </div>

            <div className="space-y-2">
              <label className="text-sm font-bold text-gray-700">الموقع</label>
              <input
                required
                type="text"
                value={formData.location}
                onChange={e => setFormData({ ...formData, location: e.target.value })}
                className="w-full bg-gray-50 border border-gray-200 rounded-xl py-3 px-4 focus:outline-none focus:border-emerald-500 transition-all"
                placeholder="مثلاً: دمشق، حي الشعلان"
              />
            </div>

            <div className="space-y-2">
              <label className="text-sm font-bold text-gray-700">الفئة الرئيسية</label>
              <select
                value={formData.mainCategoryId}
                onChange={e => {
                  const mainId = e.target.value;
                  const firstSub = MAIN_CATEGORIES.find(c => c.id === mainId)?.subCategories[0]?.id || '';
                  setFormData({ ...formData, mainCategoryId: mainId, subCategoryId: firstSub, subSubCategoryId: 'all' });
                }}
                className="w-full bg-gray-50 border border-gray-200 rounded-xl py-3 px-4 focus:outline-none focus:border-emerald-500 transition-all"
              >
                {MAIN_CATEGORIES.map(cat => (
                  <option key={cat.id} value={cat.id}>{cat.name}</option>
                ))}
              </select>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-bold text-gray-700">الفئة الفرعية</label>
              <select
                value={formData.subCategoryId}
                onChange={e => setFormData({ ...formData, subCategoryId: e.target.value, subSubCategoryId: 'all' })}
                className="w-full bg-gray-50 border border-gray-200 rounded-xl py-3 px-4 focus:outline-none focus:border-emerald-500 transition-all"
              >
                {selectedMainCategory?.subCategories.map(sub => (
                  <option key={sub.id} value={sub.id}>{sub.name}</option>
                ))}
              </select>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-bold text-gray-700">الفئة الفرعية الدقيقة (اختياري)</label>
              <select
                value={formData.subSubCategoryId}
                onChange={e => setFormData({ ...formData, subSubCategoryId: e.target.value })}
                className="w-full bg-gray-50 border border-gray-200 rounded-xl py-3 px-4 focus:outline-none focus:border-emerald-500 transition-all"
              >
                <option value="all">لا يوجد</option>
                {selectedSubCategory?.subCategories?.map(ss => (
                  <option key={ss.id} value={ss.id}>{ss.name}</option>
                ))}
              </select>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-bold text-gray-700">نوع الخدمة</label>
              <input
                required
                type="text"
                value={formData.type}
                onChange={e => setFormData({ ...formData, type: e.target.value })}
                className="w-full bg-gray-50 border border-gray-200 rounded-xl py-3 px-4 focus:outline-none focus:border-emerald-500 transition-all"
                placeholder="مثلاً: فندق، شقة، عيادة"
              />
            </div>

            <div className="space-y-2">
              <label className="text-sm font-bold text-gray-700">السعر (بالدولار)</label>
              <input
                required
                type="number"
                value={formData.price}
                onChange={e => setFormData({ ...formData, price: Number(e.target.value) })}
                className="w-full bg-gray-50 border border-gray-200 rounded-xl py-3 px-4 focus:outline-none focus:border-emerald-500 transition-all"
              />
            </div>

            <div className="space-y-2">
              <label className="text-sm font-bold text-gray-700">السعر الأصلي (اختياري)</label>
              <input
                type="number"
                value={formData.originalPrice}
                onChange={e => setFormData({ ...formData, originalPrice: Number(e.target.value) })}
                className="w-full bg-gray-50 border border-gray-200 rounded-xl py-3 px-4 focus:outline-none focus:border-emerald-500 transition-all"
              />
            </div>
          </div>

          <div className="space-y-2">
            <label className="text-sm font-bold text-gray-700">رابط الصورة</label>
            <input
              required
              type="text"
              value={formData.images[0]}
              onChange={e => setFormData({ ...formData, images: [e.target.value] })}
              className="w-full bg-gray-50 border border-gray-200 rounded-xl py-3 px-4 focus:outline-none focus:border-emerald-500 transition-all"
              placeholder="https://..."
            />
          </div>

          <div className="space-y-2">
            <label className="text-sm font-bold text-gray-700">المميزات (افصل بينها بفاصلة)</label>
            <textarea
              value={formData.amenities}
              onChange={e => setFormData({ ...formData, amenities: e.target.value })}
              className="w-full bg-gray-50 border border-gray-200 rounded-xl py-3 px-4 focus:outline-none focus:border-emerald-500 transition-all h-24"
              placeholder="واي فاي، تكييف، إفطار مجاني..."
            />
          </div>

          <div className="space-y-2">
            <label className="text-sm font-bold text-gray-700">ميزات إضافية (افصل بينها بفاصلة)</label>
            <textarea
              value={formData.features}
              onChange={e => setFormData({ ...formData, features: e.target.value })}
              className="w-full bg-gray-50 border border-gray-200 rounded-xl py-3 px-4 focus:outline-none focus:border-emerald-500 transition-all h-24"
              placeholder="إلغاء مجاني، دفع عند الوصول..."
            />
          </div>

          <div className="pt-6 flex gap-4">
            <button
              type="submit"
              disabled={loading}
              className="flex-1 bg-emerald-600 text-white py-4 rounded-2xl font-bold text-lg hover:bg-emerald-700 transition-all flex items-center justify-center gap-2 shadow-lg shadow-emerald-100"
            >
              {loading ? <Loader2 className="w-6 h-6 animate-spin" /> : (service ? 'تحديث الخدمة' : 'إضافة الخدمة')}
            </button>
            <button
              type="button"
              onClick={onClose}
              className="flex-1 bg-gray-100 text-gray-700 py-4 rounded-2xl font-bold text-lg hover:bg-gray-200 transition-all"
            >
              إلغاء
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
