import React, { useState, useEffect } from 'react';
import { Loader2, AlertCircle, CheckCircle2, XCircle, Clock, User, Mail, Calendar as CalendarIcon } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import { db } from '../../firebase';
import { collection, query, where, getDocs, updateDoc, doc, orderBy } from 'firebase/firestore';
import toast from 'react-hot-toast';

interface Booking {
  id: string;
  serviceId: string;
  serviceTitle: string;
  providerId: string;
  userId: string;
  userEmail: string;
  checkIn: string;
  checkOut: string;
  guests: number;
  totalPrice: number;
  status: 'pending' | 'confirmed' | 'cancelled';
  createdAt: any;
}

export default function BookingManagement() {
  const { user } = useAuth();
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchBookings = async () => {
    if (!user) return;
    setLoading(true);
    try {
      const q = query(
        collection(db, 'bookings'),
        where('providerId', '==', user.uid),
        orderBy('createdAt', 'desc')
      );
      const querySnapshot = await getDocs(q);
      const data = querySnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Booking));
      setBookings(data);
    } catch (err) {
      console.error('Error fetching provider bookings:', err);
      setError('فشل في تحميل الحجوزات. يرجى المحاولة مرة أخرى.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchBookings();
  }, [user]);

  const handleUpdateStatus = async (bookingId: string, newStatus: 'confirmed' | 'cancelled') => {
    try {
      await updateDoc(doc(db, 'bookings', bookingId), {
        status: newStatus
      });
      setBookings(prev => prev.map(b => b.id === bookingId ? { ...b, status: newStatus } : b));
      toast.success(newStatus === 'confirmed' ? 'تم تأكيد الحجز بنجاح' : 'تم إلغاء الحجز');
    } catch (err) {
      console.error('Error updating booking status:', err);
      toast.error('فشل في تحديث حالة الحجز.');
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <Loader2 className="w-8 h-8 animate-spin text-emerald-600" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <h3 className="text-xl font-bold text-gray-900">إدارة الحجوزات</h3>

      {error && (
        <div className="bg-red-50 text-red-700 p-4 rounded-xl flex items-center gap-3 border border-red-100">
          <AlertCircle className="w-5 h-5" />
          <p>{error}</p>
        </div>
      )}

      <div className="grid grid-cols-1 gap-6">
        {bookings.length === 0 ? (
          <div className="bg-white rounded-3xl shadow-sm border border-gray-100 p-12 text-center text-gray-500">
            لا توجد حجوزات حالياً.
          </div>
        ) : (
          bookings.map((booking) => (
            <div key={booking.id} className="bg-white rounded-3xl shadow-sm border border-gray-100 overflow-hidden hover:shadow-md transition-shadow">
              <div className="p-6">
                <div className="flex flex-col md:flex-row justify-between gap-6">
                  <div className="space-y-4">
                    <div className="flex items-center gap-3">
                      <div className={`p-2 rounded-lg ${
                        booking.status === 'confirmed' ? 'bg-emerald-50 text-emerald-600' :
                        booking.status === 'cancelled' ? 'bg-red-50 text-red-600' :
                        'bg-amber-50 text-amber-600'
                      }`}>
                        {booking.status === 'confirmed' ? <CheckCircle2 className="w-5 h-5" /> :
                         booking.status === 'cancelled' ? <XCircle className="w-5 h-5" /> :
                         <Clock className="w-5 h-5" />}
                      </div>
                      <div>
                        <h4 className="font-bold text-gray-900">{booking.serviceTitle}</h4>
                        <p className="text-xs text-gray-500">معرف الحجز: {booking.id}</p>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div className="flex items-center gap-2 text-sm text-gray-600">
                        <CalendarIcon className="w-4 h-4 text-gray-400" />
                        <span>{booking.checkIn} إلى {booking.checkOut}</span>
                      </div>
                      <div className="flex items-center gap-2 text-sm text-gray-600">
                        <User className="w-4 h-4 text-gray-400" />
                        <span>{booking.guests} ضيوف</span>
                      </div>
                      <div className="flex items-center gap-2 text-sm text-gray-600">
                        <Mail className="w-4 h-4 text-gray-400" />
                        <span>{booking.userEmail}</span>
                      </div>
                      <div className="flex items-center gap-2 text-sm font-bold text-emerald-600">
                        <span>إجمالي المبلغ: ${booking.totalPrice}</span>
                      </div>
                    </div>
                  </div>

                  <div className="flex flex-col justify-center gap-3 min-w-[150px]">
                    {booking.status === 'pending' && (
                      <>
                        <button
                          onClick={() => handleUpdateStatus(booking.id, 'confirmed')}
                          className="w-full py-2 bg-emerald-600 text-white rounded-xl font-bold hover:bg-emerald-700 transition-colors"
                        >
                          تأكيد الحجز
                        </button>
                        <button
                          onClick={() => handleUpdateStatus(booking.id, 'cancelled')}
                          className="w-full py-2 bg-red-50 text-red-600 rounded-xl font-bold hover:bg-red-100 transition-colors"
                        >
                          إلغاء الحجز
                        </button>
                      </>
                    )}
                    {booking.status === 'confirmed' && (
                      <div className="text-center py-2 bg-emerald-50 text-emerald-700 rounded-xl font-bold">
                        مؤكد
                      </div>
                    )}
                    {booking.status === 'cancelled' && (
                      <div className="text-center py-2 bg-red-50 text-red-700 rounded-xl font-bold">
                        ملغي
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
