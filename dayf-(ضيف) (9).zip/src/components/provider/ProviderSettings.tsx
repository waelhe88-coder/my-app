import React, { useState } from 'react';
import { useAuth } from '../../contexts/AuthContext';
import { db } from '../../firebase';
import { doc, updateDoc } from 'firebase/firestore';
import { Save, Loader2, Bell, Shield, CreditCard, User } from 'lucide-react';
import toast from 'react-hot-toast';

export default function ProviderSettings() {
  const { user, userProfile } = useAuth();
  const [isSaving, setIsSaving] = useState(false);
  const [settings, setSettings] = useState({
    notificationsEnabled: true,
    emailAlerts: true,
    autoConfirmBookings: false,
    paymentMethod: 'bank_transfer'
  });

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;

    setIsSaving(true);
    try {
      // In a real app, you would save these to a 'provider_settings' collection
      // or update the user document. For now, we'll just simulate saving.
      await new Promise(resolve => setTimeout(resolve, 1000));
      toast.success('تم حفظ الإعدادات بنجاح');
    } catch (error) {
      console.error("Error saving settings:", error);
      toast.error('فشل في حفظ الإعدادات');
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="bg-white rounded-3xl shadow-sm border border-gray-100 p-8">
      <div className="flex items-center gap-3 mb-8 pb-6 border-b border-gray-100">
        <div className="w-12 h-12 bg-emerald-50 rounded-xl flex items-center justify-center text-emerald-600">
          <User className="w-6 h-6" />
        </div>
        <div>
          <h3 className="text-xl font-bold text-gray-900">إعدادات الحساب</h3>
          <p className="text-sm text-gray-500">إدارة تفضيلات الإشعارات والحجوزات</p>
        </div>
      </div>

      <form onSubmit={handleSave} className="space-y-8 max-w-2xl">
        {/* Notifications Section */}
        <div className="space-y-4">
          <h4 className="text-lg font-bold text-gray-900 flex items-center gap-2">
            <Bell className="w-5 h-5 text-gray-400" />
            الإشعارات والتنبيهات
          </h4>
          
          <div className="space-y-3 pl-7">
            <label className="flex items-center gap-3 cursor-pointer">
              <input 
                type="checkbox" 
                checked={settings.notificationsEnabled}
                onChange={(e) => setSettings({...settings, notificationsEnabled: e.target.checked})}
                className="w-5 h-5 rounded border-gray-300 text-emerald-600 focus:ring-emerald-500"
              />
              <span className="text-gray-700 font-medium">تفعيل إشعارات التطبيق</span>
            </label>
            
            <label className="flex items-center gap-3 cursor-pointer">
              <input 
                type="checkbox" 
                checked={settings.emailAlerts}
                onChange={(e) => setSettings({...settings, emailAlerts: e.target.checked})}
                className="w-5 h-5 rounded border-gray-300 text-emerald-600 focus:ring-emerald-500"
              />
              <span className="text-gray-700 font-medium">تلقي تنبيهات عبر البريد الإلكتروني للحجوزات الجديدة</span>
            </label>
          </div>
        </div>

        {/* Booking Preferences */}
        <div className="space-y-4 pt-6 border-t border-gray-100">
          <h4 className="text-lg font-bold text-gray-900 flex items-center gap-2">
            <Shield className="w-5 h-5 text-gray-400" />
            تفضيلات الحجز
          </h4>
          
          <div className="space-y-3 pl-7">
            <label className="flex items-center gap-3 cursor-pointer">
              <input 
                type="checkbox" 
                checked={settings.autoConfirmBookings}
                onChange={(e) => setSettings({...settings, autoConfirmBookings: e.target.checked})}
                className="w-5 h-5 rounded border-gray-300 text-emerald-600 focus:ring-emerald-500"
              />
              <div>
                <span className="text-gray-700 font-medium block">تأكيد الحجوزات تلقائياً</span>
                <span className="text-xs text-gray-500">سيتم قبول جميع طلبات الحجز المتاحة فوراً دون الحاجة لموافقتك</span>
              </div>
            </label>
          </div>
        </div>

        {/* Payment Methods */}
        <div className="space-y-4 pt-6 border-t border-gray-100">
          <h4 className="text-lg font-bold text-gray-900 flex items-center gap-2">
            <CreditCard className="w-5 h-5 text-gray-400" />
            طريقة استلام الأرباح
          </h4>
          
          <div className="pl-7">
            <select 
              value={settings.paymentMethod}
              onChange={(e) => setSettings({...settings, paymentMethod: e.target.value})}
              className="w-full bg-gray-50 border border-gray-200 rounded-xl py-3 px-4 focus:outline-none focus:border-emerald-500 transition-all"
            >
              <option value="bank_transfer">تحويل بنكي</option>
              <option value="paypal">PayPal</option>
              <option value="cash">نقداً (عند الوصول)</option>
            </select>
          </div>
        </div>

        <div className="pt-8 border-t border-gray-100">
          <button
            type="submit"
            disabled={isSaving}
            className="bg-emerald-600 text-white px-8 py-3 rounded-xl font-bold hover:bg-emerald-700 transition-all flex items-center gap-2 shadow-lg shadow-emerald-100 disabled:opacity-50"
          >
            {isSaving ? <Loader2 className="w-5 h-5 animate-spin" /> : <Save className="w-5 h-5" />}
            <span>حفظ الإعدادات</span>
          </button>
        </div>
      </form>
    </div>
  );
}
