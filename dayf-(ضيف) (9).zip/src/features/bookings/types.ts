import { Timestamp } from 'firebase/firestore';

export interface Booking {
  id: string;
  serviceId: string;
  serviceTitle: string;
  userId: string;
  userEmail: string;
  providerId: string;
  checkIn: string;
  checkOut: string;
  guests: number;
  totalPrice: number;
  status: 'pending' | 'confirmed' | 'cancelled';
  createdAt: Timestamp;
}
