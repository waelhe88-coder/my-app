import { initializeApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { initializeFirestore, enableIndexedDbPersistence } from 'firebase/firestore';
import firebaseConfig from '../firebase-applet-config.json';

// Initialize Firebase
const app = initializeApp(firebaseConfig);

// Initialize Firebase services with aggressive connectivity settings for restricted environments
export const db = initializeFirestore(app, {
  experimentalForceLongPolling: true, // Force long-polling
  host: 'firestore.googleapis.com',   // Explicitly set host
  ssl: true,                          // Force SSL
}, firebaseConfig.firestoreDatabaseId);

// Enable persistence for better offline support
enableIndexedDbPersistence(db).catch((err) => {
  if (err.code === 'failed-precondition') {
    // Multiple tabs open, persistence can only be enabled in one tab at a a time.
    console.warn('Firestore persistence failed: multiple tabs open');
  } else if (err.code === 'unimplemented') {
    // The current browser doesn't support all of the features required to enable persistence
    console.warn('Firestore persistence is not supported by this browser');
  }
});

export const auth = getAuth(app);
