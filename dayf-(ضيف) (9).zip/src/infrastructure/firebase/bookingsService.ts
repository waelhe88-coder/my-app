import { db } from '../../firebase';
import { collection, query, where, orderBy, onSnapshot, doc, updateDoc, addDoc, serverTimestamp } from 'firebase/firestore';
import { Booking } from '../../features/bookings/types';

export const subscribeToBookings = (userId: string, callback: (bookings: Booking[]) => void, errorCallback: (error: Error) => void) => {
  const q = query(
    collection(db, 'bookings'),
    where('userId', '==', userId),
    orderBy('createdAt', 'desc')
  );

  return onSnapshot(q, (snapshot) => {
    const bookingsData = snapshot.docs.map(doc => ({
      id: doc.id,
      ...doc.data()
    })) as Booking[];
    callback(bookingsData);
  }, errorCallback);
};

export const createBooking = async (bookingData: Omit<Booking, 'id' | 'createdAt'>) => {
  await addDoc(collection(db, 'bookings'), {
    ...bookingData,
    createdAt: serverTimestamp()
  });
};

export const updateProviderRole = async (userId: string) => {
  await updateDoc(doc(db, 'users', userId), {
    role: 'provider'
  });
};
