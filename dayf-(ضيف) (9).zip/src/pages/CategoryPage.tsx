import React, { useState, useMemo, useEffect } from 'react';
import { useParams, Link, useNavigate, useLocation } from 'react-router-dom';
import { motion, AnimatePresence } from 'motion/react';
import { ChevronRight, Filter, Search, Map, SlidersHorizontal, ChevronDown, List, Star, Check, Sparkles, Loader2, Plus, Minus, MapPin } from 'lucide-react';
import toast from 'react-hot-toast';
import { MAIN_CATEGORIES } from '../data/categories';
import ServiceCard from '../components/ServiceCard';
import { GoogleGenAI } from '@google/genai';
import { getServicesByCategory, seedServices, Service } from '../infrastructure/firebase/serviceService';
import { useAuth } from '../contexts/AuthContext';
import { MapContainer, TileLayer, Marker, Popup } from 'react-leaflet';
import 'leaflet/dist/leaflet.css';
import L from 'leaflet';

const ai = new GoogleGenAI({ apiKey: import.meta.env.VITE_GEMINI_API_KEY || process.env.GEMINI_API_KEY || '' });

const getCoordinates = (service: Service): [number, number] => {
  const loc = service.location.toLowerCase();
  let base: [number, number] = [34.8021, 38.9968]; // Default Syria
  if (loc.includes('دمشق')) base = [33.5138, 36.2765];
  else if (loc.includes('حلب')) base = [36.2021, 37.1343];
  else if (loc.includes('اللاذقية')) base = [35.5283, 35.7813];
  else if (loc.includes('حمص')) base = [34.7324, 36.7137];
  else if (loc.includes('طرطوس')) base = [34.8890, 35.8866];
  
  // Add slight random offset based on ID so markers don't overlap perfectly
  const hash = service.id.split('').reduce((acc, char) => acc + char.charCodeAt(0), 0);
  const latOffset = (hash % 100) / 5000;
  const lngOffset = ((hash * 2) % 100) / 5000;
  
  return [base[0] + latOffset, base[1] + lngOffset];
};

const createPriceIcon = (price: number) => {
  return L.divIcon({
    className: 'custom-price-marker',
    html: `<div style="background-color: white; padding: 6px 10px; border-radius: 9999px; box-shadow: 0 2px 8px rgba(0,0,0,0.15); border: 1px solid #e5e7eb; font-weight: bold; font-size: 14px; white-space: nowrap; transition: transform 0.2s; color: #111827;">$${price}</div>`,
    iconSize: [40, 28],
    iconAnchor: [20, 14],
  });
};

export default function CategoryPage() {
  const { categoryId } = useParams();
  const navigate = useNavigate();
  const location = useLocation();
  const { user } = useAuth();
  
  // State
  const [services, setServices] = useState<Service[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [activeSubCategory, setActiveSubCategory] = useState<string>('all');
  const [activeSubSubCategory, setActiveSubSubCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [sortBy, setSortBy] = useState('recommended');
  const [maxPrice, setMaxPrice] = useState<number>(1000);
  const [showFilters, setShowFilters] = useState(false);
  const [viewMode, setViewMode] = useState<'grid' | 'map'>('grid');
  
  // Advanced Filters State
  const [selectedAmenities, setSelectedAmenities] = useState<string[]>([]);
  const [minRating, setMinRating] = useState<number>(0);
  const [selectedTypes, setSelectedTypes] = useState<string[]>([]);

  // AI Search State
  const [isAILoading, setIsAILoading] = useState(false);
  const [aiRecommendedIds, setAiRecommendedIds] = useState<string[] | null>(null);
  const [aiExplanation, setAiExplanation] = useState<string | null>(null);

  const category = MAIN_CATEGORIES.find(c => c.id === categoryId);

  // Fetch services from Firestore
  const fetchServices = async () => {
    if (!categoryId) return;
    setLoading(true);
    setError(null);
    try {
      // Seed if first time and user is logged in
      if (user) {
        await seedServices(user.uid);
      }
      const data = await getServicesByCategory(categoryId);
      setServices(data);
      if (data.length === 0) {
        // If data is empty, it might be a connection issue or just no services
        console.log("No services found for this category.");
      }
    } catch (error) {
      console.error("Error fetching services:", error);
      setError("عذراً، حدث خطأ أثناء تحميل البيانات. يرجى التحقق من اتصال الإنترنت والمحاولة مرة أخرى.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchServices();
  }, [categoryId, user]);

  // Read subcategory and AI query from URL query params
  useEffect(() => {
    const params = new URLSearchParams(location.search);
    const sub = params.get('sub');
    const subsub = params.get('subsub');
    const aiQuery = params.get('ai_query');
    const searchParam = params.get('search');

    if (searchParam) {
      setSearchQuery(searchParam);
    }

    if (sub && category?.subCategories.some(s => s.id === sub)) {
      setActiveSubCategory(sub);
      const subCat = category.subCategories.find(s => s.id === sub);
      if (subsub && subCat?.subCategories?.some(ss => ss.id === subsub)) {
        setActiveSubSubCategory(subsub);
      } else {
        setActiveSubSubCategory('all');
      }
    } else {
      setActiveSubCategory('all');
      setActiveSubSubCategory('all');
    }

    if (aiQuery && services.length > 0) {
      performAISearch(aiQuery);
    } else {
      setAiRecommendedIds(null);
      setAiExplanation(null);
    }
  }, [location.search, category, services.length]);

  const performAISearch = async (query: string) => {
    setIsAILoading(true);
    setAiRecommendedIds(null);
    setAiExplanation(null);
    
    try {
      const servicesContext = services.map(s => 
        `ID: ${s.id} | Title: ${s.title} | Location: ${s.location} | Price: $${s.price} | Rating: ${s.rating} | Type: ${s.type} | Amenities: ${s.amenities?.join(',')}`
      ).join('\n');

      const prompt = `
أنت مساعد بحث ذكي لمنصة "ضيف". يبحث المستخدم عن: "${query}".
إليك قائمة بالخدمات المتاحة في هذا القسم:
${servicesContext}

بناءً على طلب المستخدم، اختر أفضل الخدمات المطابقة.
يجب أن يكون ردك بصيغة JSON فقط، يحتوي على مصفوفتين:
1. "recommendedIds": مصفوفة تحتوي على معرفات (IDs) الخدمات المطابقة (نصوص).
2. "explanation": نص قصير باللغة العربية يشرح سبب اختيارك لهذه الخدمات.

مثال للرد:
{
  "recommendedIds": ["1", "3"],
  "explanation": "لقد وجدت لك بعض الفنادق الرخيصة في دمشق القديمة التي تناسب ميزانيتك."
}
`;

      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: prompt,
        config: {
          responseMimeType: 'application/json',
        }
      });

      const result = JSON.parse(response.text || '{}');
      if (result.recommendedIds && Array.isArray(result.recommendedIds)) {
        setAiRecommendedIds(result.recommendedIds);
        setAiExplanation(result.explanation || 'تم العثور على هذه النتائج بناءً على طلبك.');
      }
    } catch (error) {
      console.error('AI Search Error:', error);
      setAiExplanation('عذراً، حدث خطأ أثناء معالجة طلبك الذكي. نعرض لك جميع النتائج.');
    } finally {
      setIsAILoading(false);
    }
  };

  const renderMapView = () => (
    <div className="bg-gray-100 rounded-3xl h-[600px] relative overflow-hidden border border-gray-200 shadow-inner z-0">
      <MapContainer 
        center={[34.8021, 38.9968]} 
        zoom={6} 
        style={{ height: '100%', width: '100%', zIndex: 0 }}
      >
        <TileLayer
          url="https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png"
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors &copy; <a href="https://carto.com/attributions">CARTO</a>'
        />
        {filteredAndSortedServices.map((service) => {
          const position = getCoordinates(service);
          return (
            <Marker 
              key={service.id} 
              position={position}
              icon={createPriceIcon(service.price)}
            >
              <Popup className="custom-popup" closeButton={false}>
                <div className="w-56">
                  <img src={service.images[0]} alt={service.title} className="w-full h-36 object-cover rounded-t-xl" referrerPolicy="no-referrer" />
                  <div className="p-4">
                    <h4 className="font-bold text-gray-900 text-sm mb-1 truncate">{service.title}</h4>
                    <p className="text-gray-500 text-xs mb-2 truncate">{service.location}</p>
                    <div className="flex justify-between items-center">
                      <span className="font-bold text-emerald-600">${service.price}</span>
                      <div className="flex items-center gap-1 text-xs">
                        <Star className="w-3 h-3 text-amber-400 fill-current" />
                        <span>{service.rating}</span>
                      </div>
                    </div>
                    <Link to={`/listing/${service.id}`} className="block w-full text-center bg-emerald-600 text-white py-1.5 rounded-lg mt-3 text-xs font-bold hover:bg-emerald-700">
                      عرض التفاصيل
                    </Link>
                  </div>
                </div>
              </Popup>
            </Marker>
          );
        })}
      </MapContainer>
    </div>
  );

  // Redirect if not found
  if (!category) {
    navigate('/');
    return null;
  }

  // Derived styling classes
  const colorClasses = {
    emerald: 'bg-emerald-600 text-white',
    blue: 'bg-blue-600 text-white',
    amber: 'bg-amber-500 text-white',
    purple: 'bg-purple-600 text-white',
  };

  const textClasses = {
    emerald: 'text-emerald-600',
    blue: 'text-blue-600',
    amber: 'text-amber-600',
    purple: 'text-purple-600',
  };

  const bgLightClasses = {
    emerald: 'bg-emerald-50',
    blue: 'bg-blue-50',
    amber: 'bg-amber-50',
    purple: 'bg-purple-50',
  };

  const borderClasses = {
    emerald: 'border-emerald-600',
    blue: 'border-blue-600',
    amber: 'border-amber-500',
    purple: 'border-purple-600',
  };

  const activeColorClass = colorClasses[category.color as keyof typeof colorClasses];
  const activeTextClass = textClasses[category.color as keyof typeof textClasses];
  const activeBgLightClass = bgLightClasses[category.color as keyof typeof bgLightClasses];
  const activeBorderClass = borderClasses[category.color as keyof typeof borderClasses];

  // Extract unique amenities and types for filters based on current category
  const { availableAmenities, availableTypes } = useMemo(() => {
    const amenities = new Set<string>();
    const types = new Set<string>();
    services.forEach(s => {
      s.amenities?.forEach(a => amenities.add(a));
      if (s.type) types.add(s.type);
    });
    return {
      availableAmenities: Array.from(amenities),
      availableTypes: Array.from(types)
    };
  }, [services]);

  // Filtering & Sorting Logic
  const filteredAndSortedServices = useMemo(() => {
    let result = services.filter(service => {
      const matchesMain = service.mainCategoryId === category.id;
      
      if (aiRecommendedIds) {
        return matchesMain && aiRecommendedIds.includes(service.id);
      }

      const matchesSub = activeSubCategory === 'all' || service.subCategoryId === activeSubCategory;
      const matchesSubSub = activeSubSubCategory === 'all' || service.subSubCategoryId === activeSubSubCategory;
      const matchesSearch = service.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
                            service.location.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesPrice = service.price <= maxPrice;
      const matchesRating = service.rating >= minRating;
      
      const matchesAmenities = selectedAmenities.length === 0 || 
        selectedAmenities.every(amenity => service.amenities?.includes(amenity));
        
      const matchesTypes = selectedTypes.length === 0 || 
        selectedTypes.includes(service.type);
      
      return matchesMain && matchesSub && matchesSubSub && matchesSearch && matchesPrice && matchesRating && matchesAmenities && matchesTypes;
    });

    switch (sortBy) {
      case 'price-asc':
        result.sort((a, b) => a.price - b.price);
        break;
      case 'price-desc':
        result.sort((a, b) => b.price - a.price);
        break;
      case 'rating-desc':
        result.sort((a, b) => b.rating - a.rating);
        break;
      case 'recommended':
      default:
        result.sort((a, b) => {
          if (a.isPopular && !b.isPopular) return -1;
          if (!a.isPopular && b.isPopular) return 1;
          return b.rating - a.rating;
        });
        break;
    }

    return result;
  }, [services, category.id, activeSubCategory, activeSubSubCategory, searchQuery, maxPrice, sortBy, minRating, selectedAmenities, selectedTypes, aiRecommendedIds]);

  const toggleAmenity = (amenity: string) => {
    setSelectedAmenities(prev => 
      prev.includes(amenity) ? prev.filter(a => a !== amenity) : [...prev, amenity]
    );
  };

  const toggleType = (type: string) => {
    setSelectedTypes(prev => 
      prev.includes(type) ? prev.filter(t => t !== type) : [...prev, type]
    );
  };

  const clearFilters = () => {
    setMaxPrice(1000);
    setSearchQuery('');
    setMinRating(0);
    setSelectedAmenities([]);
    setSelectedTypes([]);
  };

  const handleSubCategoryClick = (subId: string) => {
    setActiveSubCategory(subId);
    setActiveSubSubCategory('all');
    // Update URL without full page reload
    const newUrl = subId === 'all' ? `/category/${category.id}` : `/category/${category.id}?sub=${subId}`;
    navigate(newUrl, { replace: true });
  };

  const handleSubSubCategoryClick = (subSubId: string) => {
    setActiveSubSubCategory(subSubId);
    // Update URL
    const newUrl = subSubId === 'all' 
      ? `/category/${category.id}?sub=${activeSubCategory}` 
      : `/category/${category.id}?sub=${activeSubCategory}&subsub=${subSubId}`;
    navigate(newUrl, { replace: true });
  };

  const currentSubCategory = category.subCategories.find(s => s.id === activeSubCategory);

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Sticky Top Bar (Subcategories & Search) */}
      <div className="sticky top-16 z-40 bg-white border-b border-gray-200 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex flex-col gap-4">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
              
              {/* Sub-categories Tabs - Level 2 */}
              <div className="flex overflow-x-auto md:flex-wrap gap-4 md:gap-6 pb-2 w-full flex-1 snap-x -mx-4 px-4 sm:mx-0 sm:px-0">
                <button
                  onClick={() => handleSubCategoryClick('all')}
                  className={`flex flex-col items-center gap-2 min-w-[70px] pb-3 border-b-2 transition-all shrink-0 snap-start ${
                    activeSubCategory === 'all' 
                      ? `${activeBorderClass} ${activeTextClass}` 
                      : 'border-transparent text-gray-500 hover:text-gray-900 hover:border-gray-300'
                  }`}
                >
                  <div className="w-10 h-10 md:w-8 md:h-8 flex items-center justify-center bg-gray-100 rounded-full mb-1">
                    <category.icon className="w-5 h-5 md:w-4 md:h-4" />
                  </div>
                  <span className="text-xs md:text-sm font-medium whitespace-nowrap">الكل</span>
                </button>
                
                {category.subCategories.map((sub) => (
                  <button
                    key={sub.id}
                    onClick={() => handleSubCategoryClick(sub.id)}
                    className={`flex flex-col items-center gap-2 min-w-[70px] pb-3 border-b-2 transition-all shrink-0 snap-start ${
                      activeSubCategory === sub.id 
                        ? `${activeBorderClass} ${activeTextClass}` 
                        : 'border-transparent text-gray-500 hover:text-gray-900 hover:border-gray-300'
                    }`}
                  >
                    <div className="text-3xl md:text-2xl mb-1 opacity-80">{sub.icon}</div>
                    <span className="text-xs md:text-sm font-medium whitespace-nowrap">{sub.name}</span>
                  </button>
                ))}
              </div>

              {/* Search & Actions */}
              <div className="flex items-center gap-3 shrink-0">
                <div className="relative">
                  <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                  <input 
                    type="text"
                    placeholder="ابحث عن وجهة أو خدمة..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-4 pr-10 py-2.5 bg-gray-50 border border-gray-200 rounded-full text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 w-full md:w-64 transition-all"
                  />
                </div>
                <button 
                  onClick={() => setShowFilters(!showFilters)}
                  className={`lg:hidden flex items-center justify-center w-10 h-10 border rounded-full transition-colors ${showFilters ? activeColorClass : 'bg-white border-gray-200 text-gray-700 hover:bg-gray-50'}`}
                >
                  <SlidersHorizontal className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Sub-Sub-categories Tabs - Level 3 */}
            {currentSubCategory && currentSubCategory.subCategories && (
              <motion.div 
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                className="flex overflow-x-auto md:flex-wrap gap-2 md:gap-3 pb-2 border-t border-gray-50 pt-3 snap-x -mx-4 px-4 sm:mx-0 sm:px-0"
              >
                <button
                  onClick={() => handleSubSubCategoryClick('all')}
                  className={`px-4 py-2 md:py-1.5 rounded-full text-xs md:text-sm font-bold transition-all whitespace-nowrap border shrink-0 snap-start ${
                    activeSubSubCategory === 'all'
                      ? `${activeColorClass} border-transparent`
                      : 'bg-gray-50 text-gray-600 border-gray-200 hover:border-gray-300'
                  }`}
                >
                  الكل في {currentSubCategory.name}
                </button>
                {currentSubCategory.subCategories.map((ss) => (
                  <button
                    key={ss.id}
                    onClick={() => handleSubSubCategoryClick(ss.id)}
                    className={`px-4 py-2 md:py-1.5 rounded-full text-xs md:text-sm font-bold transition-all whitespace-nowrap border shrink-0 snap-start ${
                      activeSubSubCategory === ss.id
                        ? `${activeColorClass} border-transparent`
                        : 'bg-white text-gray-600 border-gray-200 hover:border-gray-300'
                    }`}
                  >
                    {ss.name}
                  </button>
                ))}
              </motion.div>
            )}
          </div>
        </div>
      </div>

      {/* Main Content Area */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-4 pb-24 md:pb-8">
        
        {/* Floating Map Button (All Screens) */}
        <div className="fixed bottom-20 left-1/2 -translate-x-1/2 z-40">
          <button 
            onClick={() => setViewMode(viewMode === 'grid' ? 'map' : 'grid')}
            className="flex items-center gap-2 bg-slate-900 text-white px-6 py-3 rounded-full shadow-xl font-bold text-sm hover:scale-105 active:scale-95 transition-all"
          >
            <span>{viewMode === 'grid' ? 'الخريطة' : 'القائمة'}</span>
            {viewMode === 'grid' ? <Map className="w-4 h-4" /> : <List className="w-4 h-4" />}
          </button>
        </div>
        
        {/* Breadcrumbs & Title */}
        <div className="mb-8">
          <div className="flex items-center gap-2 text-sm text-gray-500 mb-4">
            <Link to="/" className="hover:text-gray-900 transition-colors">الرئيسية</Link>
            <ChevronRight className="w-4 h-4" />
            <span className="font-medium text-gray-900">{category.name}</span>
          </div>
          <div className="flex flex-col md:flex-row md:justify-between md:items-end gap-4">
            <div className="flex-1 min-w-0">
              <h1 className="text-3xl font-bold text-gray-900 mb-2 leading-tight truncate">{category.name} في سوريا</h1>
              <p className="text-gray-600 leading-relaxed line-clamp-2 md:line-clamp-none">{category.description}</p>
            </div>
            
            {/* View Mode Toggle */}
            <div className="flex items-center bg-white border border-gray-200 rounded-xl p-1 shrink-0 self-start md:self-auto shadow-sm">
              <button 
                onClick={() => setViewMode('grid')}
                className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-colors ${viewMode === 'grid' ? 'bg-gray-100 text-gray-900' : 'text-gray-500 hover:text-gray-700'}`}
              >
                <List className="w-4 h-4" />
                <span>قائمة</span>
              </button>
              <button 
                onClick={() => setViewMode('map')}
                className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-colors ${viewMode === 'map' ? 'bg-gray-100 text-gray-900' : 'text-gray-500 hover:text-gray-700'}`}
              >
                <Map className="w-4 h-4" />
                <span>خريطة</span>
              </button>
            </div>
          </div>
        </div>

        <div className="flex flex-col lg:flex-row gap-8">
          
          {/* Sidebar Filters (Desktop & Mobile) */}
          <AnimatePresence>
            {(showFilters || window.innerWidth >= 1024) && (
              <motion.aside 
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 20 }}
                className={`lg:w-1/4 shrink-0 ${showFilters ? 'block' : 'hidden lg:block'}`}
              >
                <div className="bg-white border border-gray-200 rounded-2xl p-6 sticky top-40 shadow-sm">
                  <div className="flex items-center justify-between mb-6 pb-4 border-b border-gray-100">
                    <h3 className="text-lg font-bold text-gray-900 flex items-center gap-2">
                      <Filter className="w-5 h-5" />
                      تصفية متقدمة
                    </h3>
                    {showFilters && (
                      <button onClick={() => setShowFilters(false)} className="lg:hidden text-sm text-gray-500 hover:text-gray-900">إغلاق</button>
                    )}
                  </div>

                  {/* Price Filter */}
                  <div className="mb-8">
                    <h4 className="font-semibold text-gray-900 mb-4">نطاق السعر (لليلة)</h4>
                    <div className="flex items-center justify-between text-sm text-gray-600 mb-3">
                      <span>$0</span>
                      <span className={`font-bold ${activeTextClass}`}>${maxPrice}</span>
                    </div>
                    <input 
                      type="range" 
                      min="0" 
                      max="1000" 
                      step="10"
                      value={maxPrice}
                      onChange={(e) => setMaxPrice(Number(e.target.value))}
                      className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer accent-emerald-600"
                    />
                  </div>

                  {/* Rating Filter */}
                  <div className="mb-8">
                    <h4 className="font-semibold text-gray-900 mb-4">تقييم الضيوف</h4>
                    <div className="space-y-2">
                      {[4, 3, 2].map((rating) => (
                        <label key={rating} className="flex items-center gap-3 cursor-pointer group">
                          <div className={`flex items-center justify-center w-5 h-5 border-2 rounded-md transition-colors ${minRating === rating ? 'border-emerald-500 bg-emerald-500' : 'border-gray-300 group-hover:border-emerald-500'}`}>
                            <input 
                              type="radio" 
                              name="rating" 
                              className="sr-only" 
                              checked={minRating === rating}
                              onChange={() => setMinRating(rating)}
                            />
                            {minRating === rating && <Check className="w-3.5 h-3.5 text-white" />}
                          </div>
                          <div className="flex items-center gap-1">
                            <Star className="w-4 h-4 text-amber-400 fill-current" />
                            <span className="text-gray-700 text-sm">{rating}+ نجوم</span>
                          </div>
                        </label>
                      ))}
                      <label className="flex items-center gap-3 cursor-pointer group">
                        <div className={`flex items-center justify-center w-5 h-5 border-2 rounded-md transition-colors ${minRating === 0 ? 'border-emerald-500 bg-emerald-500' : 'border-gray-300 group-hover:border-emerald-500'}`}>
                          <input 
                            type="radio" 
                            name="rating" 
                            className="sr-only" 
                            checked={minRating === 0}
                            onChange={() => setMinRating(0)}
                          />
                          {minRating === 0 && <Check className="w-3.5 h-3.5 text-white" />}
                        </div>
                        <span className="text-gray-700 text-sm">الكل</span>
                      </label>
                    </div>
                  </div>

                  {/* Property Type Filter */}
                  {availableTypes.length > 0 && (
                    <div className="mb-8">
                      <h4 className="font-semibold text-gray-900 mb-4">نوع المكان</h4>
                      <div className="space-y-3">
                        {availableTypes.map((type, idx) => (
                          <label key={idx} className="flex items-center gap-3 cursor-pointer group">
                            <div className={`flex items-center justify-center w-5 h-5 border-2 rounded-md transition-colors ${selectedTypes.includes(type) ? 'border-emerald-500 bg-emerald-500' : 'border-gray-300 group-hover:border-emerald-500'}`}>
                              <input 
                                type="checkbox" 
                                className="sr-only" 
                                checked={selectedTypes.includes(type)}
                                onChange={() => toggleType(type)}
                              />
                              {selectedTypes.includes(type) && <Check className="w-3.5 h-3.5 text-white" />}
                            </div>
                            <span className="text-gray-700 text-sm">{type}</span>
                          </label>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Amenities Filter */}
                  {availableAmenities.length > 0 && (
                    <div className="mb-8">
                      <h4 className="font-semibold text-gray-900 mb-4">المرافق والمميزات</h4>
                      <div className="space-y-3 max-h-48 overflow-y-auto pr-2">
                        {availableAmenities.map((amenity, idx) => (
                          <label key={idx} className="flex items-center gap-3 cursor-pointer group">
                            <div className={`flex items-center justify-center w-5 h-5 border-2 rounded-md transition-colors ${selectedAmenities.includes(amenity) ? 'border-emerald-500 bg-emerald-500' : 'border-gray-300 group-hover:border-emerald-500'}`}>
                              <input 
                                type="checkbox" 
                                className="sr-only" 
                                checked={selectedAmenities.includes(amenity)}
                                onChange={() => toggleAmenity(amenity)}
                              />
                              {selectedAmenities.includes(amenity) && <Check className="w-3.5 h-3.5 text-white" />}
                            </div>
                            <span className="text-gray-700 text-sm">{amenity}</span>
                          </label>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Reset Button */}
                  <button 
                    onClick={clearFilters}
                    className="w-full py-3 text-sm font-bold text-gray-600 bg-gray-50 hover:bg-gray-100 rounded-xl transition-colors border border-gray-200"
                  >
                    مسح جميع الفلاتر
                  </button>
                </div>
              </motion.aside>
            )}
          </AnimatePresence>

          {/* Results Area */}
          <main className="flex-1 min-w-0">
            {error ? (
              <div className="w-full py-20 flex flex-col items-center justify-center text-center">
                <div className="bg-red-50 text-red-600 p-8 rounded-3xl max-w-md border border-red-100 shadow-sm">
                  <p className="text-lg font-bold mb-4">{error}</p>
                  <button 
                    onClick={fetchServices}
                    className="bg-emerald-600 text-white px-8 py-3 rounded-2xl hover:bg-emerald-700 transition-all flex items-center gap-3 mx-auto font-bold shadow-lg shadow-emerald-200 active:scale-95"
                  >
                    <Loader2 className={`w-5 h-5 ${loading ? 'animate-spin' : ''}`} />
                    إعادة المحاولة
                  </button>
                </div>
              </div>
            ) : loading ? (
              <div className="w-full py-20 flex flex-col items-center justify-center text-gray-500">
                <Loader2 className="w-10 h-10 animate-spin mb-4 text-emerald-600" />
                <p className="text-lg font-medium">جاري تحميل الخدمات...</p>
              </div>
            ) : null}

            {!loading && isAILoading && (
              <div className="w-full bg-emerald-50 border border-emerald-100 rounded-2xl p-6 mb-8 flex flex-col items-center justify-center text-emerald-700">
                <Loader2 className="w-8 h-8 animate-spin mb-4" />
                <h3 className="text-lg font-bold mb-2">الذكاء الاصطناعي يبحث لك...</h3>
                <p className="text-sm opacity-80">جاري تحليل طلبك والبحث عن أفضل الخيارات المناسبة.</p>
              </div>
            )}

            {!loading && !isAILoading && aiExplanation && (
              <motion.div 
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                className="w-full bg-gradient-to-r from-emerald-50 to-teal-50 border border-emerald-100 rounded-2xl p-6 mb-8 shadow-sm relative overflow-hidden"
              >
                <div className="absolute top-0 right-0 w-32 h-32 bg-emerald-500/10 rounded-full blur-3xl -mr-10 -mt-10"></div>
                <div className="flex items-start gap-4 relative z-10">
                  <div className="w-12 h-12 bg-emerald-100 rounded-full flex items-center justify-center shrink-0">
                    <Sparkles className="w-6 h-6 text-emerald-600" />
                  </div>
                  <div>
                    <h3 className="text-lg font-bold text-gray-900 mb-2 flex items-center gap-2">
                      توصيات الذكاء الاصطناعي
                      <span className="text-xs bg-emerald-100 text-emerald-700 px-2 py-1 rounded-full font-medium">Gemini AI</span>
                    </h3>
                    <p className="text-gray-700 leading-relaxed text-sm md:text-base">{aiExplanation}</p>
                    <button 
                      onClick={() => {
                        setAiRecommendedIds(null);
                        setAiExplanation(null);
                        const newUrl = new URL(window.location.href);
                        newUrl.searchParams.delete('ai_query');
                        window.history.pushState({}, '', newUrl.toString());
                      }}
                      className="mt-4 text-sm font-bold text-emerald-600 hover:text-emerald-700 underline underline-offset-4"
                    >
                      عرض جميع النتائج
                    </button>
                  </div>
                </div>
              </motion.div>
            )}

            {!loading && (viewMode === 'map' ? (
              renderMapView()
            ) : (
              <>
                {/* Results Header */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
                  <p className="text-gray-600 font-medium">
                    تم العثور على <span className="font-bold text-gray-900">{filteredAndSortedServices.length}</span> نتيجة
                  </p>
                  
                  <div className="flex items-center gap-2 shrink-0">
                    <span className="text-sm text-gray-500">ترتيب حسب:</span>
                    <div className="relative">
                      <select 
                        value={sortBy}
                        onChange={(e) => setSortBy(e.target.value)}
                        className="appearance-none bg-white border border-gray-200 text-gray-700 py-2 pl-10 pr-4 rounded-xl text-sm font-medium focus:outline-none focus:ring-2 focus:ring-emerald-500 cursor-pointer"
                      >
                        <option value="recommended">الأوصى به</option>
                        <option value="price-asc">السعر: من الأقل للأعلى</option>
                        <option value="price-desc">السعر: من الأعلى للأقل</option>
                        <option value="rating-desc">الأعلى تقييماً</option>
                      </select>
                      <ChevronDown className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500 pointer-events-none" />
                    </div>
                  </div>
                </div>

                {/* Grid */}
                <div className="grid grid-cols-[repeat(auto-fill,minmax(200px,1fr))] gap-6 justify-items-center">
                  {filteredAndSortedServices.length > 0 ? (
                    filteredAndSortedServices.map((service) => (
                      <ServiceCard 
                        key={service.id} 
                        service={service} 
                        activeColorClass={activeColorClass}
                        activeTextClass={activeTextClass}
                        activeBgLightClass={activeBgLightClass}
                      />
                    ))
                  ) : (
                    <div className="col-span-full py-20 text-center bg-white rounded-3xl border border-gray-100 shadow-sm">
                      <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-gray-50 mb-4">
                        <Search className="w-8 h-8 text-gray-400" />
                      </div>
                      <h3 className="text-xl font-bold text-gray-900 mb-2">لا توجد نتائج مطابقة</h3>
                      <p className="text-gray-500 max-w-md mx-auto">حاول تغيير خيارات البحث، أو تقليل الفلاتر المحددة لرؤية المزيد من النتائج المتاحة.</p>
                      <button 
                        onClick={clearFilters}
                        className={`mt-6 px-6 py-2.5 rounded-xl font-medium transition-colors shadow-sm ${activeColorClass}`}
                      >
                        مسح جميع الفلاتر
                      </button>
                    </div>
                  )}
                </div>
              </>
            ))}
          </main>
        </div>
      </div>
    </div>
  );
}
