import React, { useEffect, useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { Calendar, MapPin, Clock, ChevronRight, Package, AlertCircle, CheckCircle2, XCircle, Loader2, Briefcase, Users, ShieldCheck } from 'lucide-react';
import { Link } from 'react-router-dom';
import { motion } from 'motion/react';
import toast from 'react-hot-toast';
import { Booking } from '../features/bookings/types';
import { subscribeToBookings, updateProviderRole } from '../infrastructure/firebase/bookingsService';

export default function MyBookings() {
  const { user, userProfile } = useAuth();
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [loading, setLoading] = useState(true);
  const [isUpdatingRole, setIsUpdatingRole] = useState(false);

  const isProvider = userProfile?.role === 'provider' || userProfile?.role === 'admin';

  const handleBecomeProvider = async () => {
    if (!user) return;
    setIsUpdatingRole(true);
    try {
      await updateProviderRole(user.uid);
      toast.success('تم ترقية حسابك إلى مزود خدمة بنجاح!');
      setTimeout(() => {
        window.location.reload();
      }, 1500);
    } catch (error) {
      console.error("Error becoming provider:", error);
      toast.error('فشل في تحديث الحساب. يرجى المحاولة لاحقاً.');
    } finally {
      setIsUpdatingRole(false);
    }
  };

  useEffect(() => {
    if (!user) return;

    const unsubscribe = subscribeToBookings(
      user.uid,
      (bookingsData) => {
        setBookings(bookingsData);
        setLoading(false);
      },
      (error) => {
        console.error("Error fetching bookings:", error);
        setLoading(false);
      }
    );

    return () => unsubscribe();
  }, [user]);

  const getStatusStyles = (status: string) => {
    switch (status) {
      case 'confirmed':
        return { bg: 'bg-emerald-50', text: 'text-emerald-700', icon: CheckCircle2, label: 'مؤكد' };
      case 'cancelled':
        return { bg: 'bg-red-50', text: 'text-red-700', icon: XCircle, label: 'ملغى' };
      default:
        return { bg: 'bg-amber-50', text: 'text-amber-700', icon: Clock, label: 'قيد الانتظار' };
    }
  };

  if (!user) {
    return (
      <div className="pt-32 pb-20 max-w-7xl mx-auto px-4 text-center">
        <div className="bg-white p-12 rounded-3xl shadow-sm border border-gray-100 max-w-md mx-auto">
          <AlertCircle className="w-16 h-16 text-amber-500 mx-auto mb-6" />
          <h2 className="text-2xl font-bold text-gray-900 mb-4">يرجى تسجيل الدخول</h2>
          <p className="text-gray-600 mb-8">يجب عليك تسجيل الدخول لمشاهدة حجوزاتك وإدارة طلباتك.</p>
          <Link to="/" className="inline-block bg-emerald-600 text-white px-8 py-3 rounded-xl font-bold hover:bg-emerald-700 transition-colors">
            العودة للرئيسية
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="pt-24 pb-20 bg-gray-50 min-h-screen">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 mb-2">حجوزاتي</h1>
            <p className="text-gray-600">تتبع وإدارة جميع طلبات الحجز الخاصة بك في مكان واحد.</p>
          </div>
          <div className="hidden sm:flex items-center gap-2 bg-white px-4 py-2 rounded-xl border border-gray-200 text-sm font-medium text-gray-600">
            <Package className="w-4 h-4" />
            <span>إجمالي الحجوزات: {bookings.length}</span>
          </div>
        </div>

        {loading ? (
          <div className="flex flex-col items-center justify-center py-20">
            <Loader2 className="w-10 h-10 text-emerald-600 animate-spin mb-4" />
            <p className="text-gray-500">جاري تحميل حجوزاتك...</p>
          </div>
        ) : bookings.length > 0 ? (
          <div className="space-y-6">
            {bookings.map((booking) => {
              const status = getStatusStyles(booking.status);
              const StatusIcon = status.icon;
              
              return (
                <motion.div 
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  key={booking.id} 
                  className="bg-white border border-gray-200 rounded-2xl overflow-hidden hover:shadow-md transition-shadow"
                >
                  <div className="p-6">
                    <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
                      <div className="flex-1">
                        <div className="flex items-center gap-3 mb-3">
                          <span className={`px-3 py-1 rounded-full text-xs font-bold flex items-center gap-1.5 ${status.bg} ${status.text}`}>
                            <StatusIcon className="w-3.5 h-3.5" />
                            {status.label}
                          </span>
                          <span className="text-xs text-gray-400">رقم الحجز: #{booking.id.slice(0, 8).toUpperCase()}</span>
                        </div>
                        <h3 className="text-xl font-bold text-gray-900 mb-2">{booking.serviceTitle}</h3>
                        
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-y-3 gap-x-8 mt-4">
                          <div className="flex items-center gap-2 text-gray-600 text-sm">
                            <Calendar className="w-4 h-4 text-emerald-600" />
                            <span>{booking.checkIn} - {booking.checkOut}</span>
                          </div>
                          <div className="flex items-center gap-2 text-gray-600 text-sm">
                            <MapPin className="w-4 h-4 text-emerald-600" />
                            <span>دمشق، سوريا</span>
                          </div>
                          <div className="flex items-center gap-2 text-gray-600 text-sm">
                            <Clock className="w-4 h-4 text-emerald-600" />
                            <span>تم الحجز في: {booking.createdAt?.toDate().toLocaleDateString('ar-SA')}</span>
                          </div>
                          <div className="flex items-center gap-2 text-gray-600 text-sm">
                            <Package className="w-4 h-4 text-emerald-600" />
                            <span>عدد الضيوف: {booking.guests}</span>
                          </div>
                        </div>
                      </div>

                      <div className="flex flex-col md:flex-row items-center md:items-end justify-between md:justify-center gap-4 pt-6 md:pt-0 border-t md:border-t-0 border-gray-100">
                        <div className="text-right w-full md:w-auto flex flex-row md:flex-col justify-between md:justify-end items-center md:items-end mb-2 md:mb-0">
                          <div className="text-sm text-gray-500 mb-1">السعر الإجمالي</div>
                          <div className="text-2xl font-bold text-gray-900">${booking.totalPrice}</div>
                        </div>
                        <div className="flex flex-col gap-2 w-full md:w-auto">
                          <Link 
                            to={`/listing/${booking.serviceId}`}
                            className="flex items-center justify-center gap-2 bg-emerald-50 text-emerald-700 px-4 py-2 rounded-xl font-bold hover:bg-emerald-100 transition-colors w-full"
                          >
                            <span>عرض التفاصيل</span>
                            <ChevronRight className="w-4 h-4 rotate-180" />
                          </Link>
                          {booking.status === 'confirmed' && (
                            <>
                              {/* Escrow Reassurance */}
                              <div className="p-3 bg-blue-50 rounded-xl border border-blue-100 flex items-start gap-2 mb-2">
                                <ShieldCheck className="w-4 h-4 text-blue-600 shrink-0 mt-0.5" />
                                <div className="text-right">
                                  <div className="text-[10px] font-bold text-blue-800">حماية ضيف المالية نشطة</div>
                                  <p className="text-[9px] text-blue-600 leading-tight">أموالك في أمان. سيتم تحويل المبلغ للمزود فقط بعد تأكيدك لتلقي الخدمة.</p>
                                </div>
                              </div>
                              <Link 
                                to={`/community?sub=guest-experiences`}
                                className="flex items-center justify-center gap-2 bg-white border border-gray-200 text-gray-700 px-4 py-2 rounded-xl font-bold hover:bg-gray-50 transition-colors w-full text-sm"
                              >
                                <Users className="w-4 h-4 text-emerald-600" />
                                <span>شارك تجربتك بالمجتمع</span>
                              </Link>
                              <Link 
                                to="/marketplace"
                                className="flex items-center justify-center gap-2 bg-amber-50 border border-amber-200 text-amber-700 px-4 py-2 rounded-xl font-bold hover:bg-amber-100 transition-colors w-full text-sm mt-2"
                              >
                                <Package className="w-4 h-4 text-amber-600" />
                                <span>تسوق منتجات محلية</span>
                              </Link>
                            </>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                </motion.div>
              );
            })}
          </div>
        ) : (
          <div className="bg-white py-20 px-6 rounded-3xl border border-gray-100 text-center shadow-sm">
            <div className="w-20 h-20 bg-gray-50 rounded-full flex items-center justify-center mx-auto mb-6">
              <Calendar className="w-10 h-10 text-gray-300" />
            </div>
            <h3 className="text-xl font-bold text-gray-900 mb-2">لا توجد حجوزات بعد</h3>
            <p className="text-gray-500 max-w-sm mx-auto mb-8">
              يبدو أنك لم تقم بأي حجز حتى الآن. استكشف أفضل الأماكن والخدمات في سوريا وابدأ رحلتك معنا.
            </p>
            <Link to="/" className="inline-block bg-emerald-600 text-white px-8 py-3 rounded-xl font-bold hover:bg-emerald-700 transition-colors">
              استكشف الخدمات
            </Link>
          </div>
        )}

        {!isProvider && (
          <div className="mt-16 bg-emerald-600 rounded-3xl p-8 md:p-12 text-white overflow-hidden relative">
            <div className="relative z-10 max-w-2xl">
              <h2 className="text-3xl font-bold mb-4">هل تقدم خدمات سياحية أو طبية؟</h2>
              <p className="text-emerald-50 text-lg mb-8">
                انضم إلى مئات المزودين في منصة ضيف وابدأ في استقبال الحجوزات وتوسيع نطاق عملك في سوريا.
              </p>
              <button
                onClick={handleBecomeProvider}
                disabled={isUpdatingRole}
                className="bg-white text-emerald-700 px-8 py-4 rounded-2xl font-bold text-lg hover:bg-emerald-50 transition-all flex items-center gap-2 disabled:opacity-50"
              >
                {isUpdatingRole ? (
                  <Loader2 className="w-6 h-6 animate-spin" />
                ) : (
                  <>
                    <Briefcase className="w-6 h-6" />
                    <span>سجل كمزود خدمة الآن</span>
                  </>
                )}
              </button>
            </div>
            <div className="absolute top-0 left-0 w-64 h-64 bg-white/10 rounded-full -translate-x-1/2 -translate-y-1/2 blur-3xl"></div>
            <div className="absolute bottom-0 right-0 w-96 h-96 bg-emerald-500/20 rounded-full translate-x-1/4 translate-y-1/4 blur-3xl"></div>
          </div>
        )}
      </div>
    </div>
  );
}
